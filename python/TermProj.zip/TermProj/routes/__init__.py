__all__ = ["api_bp", "html_bp"]

from .api import api_bp
from .html import html_bp